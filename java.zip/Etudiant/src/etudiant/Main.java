/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package etudiant;

import java.sql.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


/**
 *
 * @author ibrahimabenmadykebe
 */
public class Main {
    
        public static void main(String[] args) {
                
                try{
            
                    Connection cnx=connecterDB();
                    Statement st;
                    ResultSet rst;
                    
                    st = cnx.createStatement();
                    rst = st.executeQuery("SELECT * FROM contact");
                    
                    while(rst.next()){
                        System.out.print(rst.getInt("id"));
                        System.out.print(rst.getString("prenom"));
                        System.out.print(rst.getString("nom"));
                        System.out.print(rst.getInt("tel"));
                        System.out.println();
                      

                        
                    }
                    
                  

                    
                }catch(Exception ex){
                    ex.printStackTrace();
                }
            
        }
        
        
        public static Connection connecterDB(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Driver ok");
            String url="jdbc:mysql://localhost:8889/AFROACADEMY";
            String user="root";
            String password="root";
            Connection cnx=DriverManager.getConnection(url, user, password);
            System.out.println("Connection bien etablie");
            return cnx;


        }catch(Exception e){
            e.printStackTrace();
            return null;
        }
    }


    
   
    
}
