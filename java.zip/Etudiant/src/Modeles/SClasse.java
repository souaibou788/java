/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author ibrahimabenmadykebe
 */
public class SClasse{
    private int id;
    private String libelle;
    private String categorie;
     private static int nbSCat;

    public SClasse() {
        nbSCat++;
        id=nbSCat;
    }

    public SClasse(String libelle, String categorie) {
        this.libelle = libelle;
        this.categorie = categorie;
        nbSCat++;
        id=nbSCat;
    }

    public SClasse(int id, String libelle, String categorie) {
        this.id = id;
        this.libelle = libelle;
        this.categorie = categorie;
    }
    
    

    public int getId() {
        return id;
    }

    public String getLibelle() {
        return libelle;
    }

    public String getCategorie() {
        return categorie;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public void setCategorie(String categorie) {
        this.categorie = categorie;
    }

    @Override
    public String toString() {
        return "libelle=" + libelle + ", categorie=" + categorie;
    }

    
}
