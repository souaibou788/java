/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modeles;

/**
 *
 * @author ibrahimabenmadykebe
 */
public class Etudianttt extends Personne {
    private String tuteur;

    public Etudianttt(String tuteur, int id) {
        super(id);
       this.tuteur = tuteur;
    }

    public String getTuteur() {
        return tuteur;
    }

    public void setTuteur(String tuteur) {
        this.tuteur = tuteur;
    }

    @Override
    public String toString() {
        return super.toString()+"tuteur = " + tuteur ;
        //To change body of generated methods, choose Tools | Templates.
    }
     
    
    
    
    
}
