/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author ibrahimabenmadykebe
 */
public class User{
    private int id;
    private String nom;
     private String prenom;
     private static int nbUser;
    private int telephone;
     private String pwd;
     private String login;
     private String profil;

    public User() {
        nbUser++;
        id=nbUser;
    }

    public User(String nom, String prenom) {
        this.nom = nom;
        this.prenom = prenom;
        nbUser++;
        id=nbUser;
    }

    public User(int id, String nom, String prenom, String login, int telephone, String pwd, String profil) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.telephone = telephone;
        this.pwd = pwd;
        this.login = login;
        this.profil = profil;
    }

    public User(String nom, String prenom, int telephone) {
        this.nom = nom;
        this.prenom = prenom;
        this.telephone = telephone;
        nbUser++;
        id=nbUser;
    }

    public User(int id, String nom, String prenom, int telephone) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.telephone = telephone;
    }
    

    public User(String nom, String prenom, String login, int telephone, String pwd, String profil) {
        this.nom = nom;
        this.prenom = prenom;
        this.telephone = telephone;
        this.pwd = pwd;
        this.login = login;
        this.profil = profil;
        nbUser++;
        id=nbUser;
    }

    public void setProfil(String profil) {
        this.profil = profil;
    }

    
    public void setTelephone(int tel) {
        this.telephone = tel;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getProfil() {
        return profil;
    }

    
    public int getId() {
        return id;
    }

    public String getPwd() {
        return pwd;
    }

    public String getLogin() {
        return login;
    }

    public int getTelephone() {
        return telephone;
    }


    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    @Override
    public String toString() {
        return prenom +" "+ nom;
    }
    
    
       
}
