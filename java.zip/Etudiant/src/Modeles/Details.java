/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modeles;

import java.util.Date;

/**
 *
 * @author ibrahimabenmadykebe
 */
public class Details {
    private Date anneescolaire;
    protected Professeur professeur;
    protected Classe classe;

    public Details(Date anneescolaire, Professeur professeur, Classe classe) {
        this.anneescolaire = anneescolaire;
        this.professeur = professeur;
        this.classe = classe;
    }

    public Date getAnneescolaire() {
        return anneescolaire;
    }

    public Professeur getProfesseur() {
        return professeur;
    }

    public Classe getClasse() {
        return classe;
    }

    public void setAnneescolaire(Date anneescolaire) {
        this.anneescolaire = anneescolaire;
    }

    public void setProfesseur(Professeur professeur) {
        this.professeur = professeur;
    }

    public void setClasse(Classe classe) {
        this.classe = classe;
    }

    @Override
    public String toString() {
        return "Inscription(" + ", anneescolaire=" + anneescolaire + ", classe=" + classe + ", professeur=" + professeur + ')'; 
//To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    
    
}
