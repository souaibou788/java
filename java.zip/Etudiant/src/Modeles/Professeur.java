/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modeles;

/**
 *
 * @author ibrahimabenmadykebe
 */
public class Professeur extends Personne{
    private  String grade;
    protected Classe classe;

    public Professeur(String grade, int id) {
        super(id);
        this.grade = grade;
    }

    public String getGrade() {
        return grade;
    }

    public Classe getClasse() {
        return classe;
    }

    

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public void setClasse(Classe classe) {
        this.classe = classe;
    }

   
    
    
    
    
    
    
    
    
    @Override
    public String toString() {
        return super.toString() +" grade = " + grade +" classe = " + classe; 
//To change body of generated methods, choose Tools | Templates.
    }
    
    
}
