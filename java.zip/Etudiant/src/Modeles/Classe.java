/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modeles;

/**
 *
 * @author ibrahimabenmadykebe
 */
public class Classe {
    private int id;
    private String libelle;
    private static int cpt;
    
    protected Professeur professeur;

    public Classe(int id, String libelle, Professeur professeur) {
        this.id = id;
        this.libelle = libelle;
        this.professeur = professeur;
    }

    public Classe(String liage) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    public int getId() {
        return id;
    }

    public String getLibelle() {
        return libelle;
    }

    public static int getCompteur() {
        return cpt;
    }

    public Professeur getProfesseur() {
        return professeur;
    }
    
    


    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public void setProfesseur(Professeur professeur) {
        this.professeur = professeur;
    }
    
   
  

    @Override
    public String toString() {
        return "Classee(" + "id=" + id + ", libelle =" + libelle + ", professeur =" + professeur + ')'; 
        //To change body of generated methods, choose Tools | Templates.
    }

   
    
    
    
    
    
}
